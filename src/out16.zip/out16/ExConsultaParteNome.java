package out16;
import java.sql.*;
import java.util.*;
import javax.swing.JOptionPane;
public class ExConsultaParteNome {
	ConectaMySQL cm = new ConectaMySQL();
	public static void main(String[] args) throws Exception {
		MetodosComuns mc = new MetodosComuns();
		List<Aluno> alunos =  new ExConsultaParteNome().consultar(JOptionPane.showInputDialog("Dugite o nome do aluno a ser consulta"));
		System.out.println("Data:" +mc.lerData() + " Hora: " + mc.lerHora());
		for(Aluno aluno: alunos) {
			System.out.println(aluno);}}
 public List<Aluno> consultar(String nome) throws Exception{
	 String queryCmd = "select * from senac.alunos where alunoNome like ? ";
	 //asdiasdi
		}
		
	}

