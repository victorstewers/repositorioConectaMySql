package out16;

public class MetodosComuns {

}
